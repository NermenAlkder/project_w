define( [
	"./arr"
], function( arr ) {
	"use strict";

	return arr.slice;
} );
