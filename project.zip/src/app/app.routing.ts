import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


/*
الروابط الخاصة بالتطبيق
*/
const routes: Routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'index', loadChildren: './components/index/index.module#IndexModule' },
    { path: 'login', loadChildren: './components/login/login.module#LoginModule' },
    { path: 'result', loadChildren: './components/result/result.module#ResultModule' },
    { path: '**', redirectTo: '/login' }
];

export const appRoutingProviders: any[] = [];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes, { useHash: true });
