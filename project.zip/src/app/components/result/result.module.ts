
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ResultComponent } from './result.component';
import { routing } from './result.routes';
@NgModule({
  imports:
    [
      CommonModule,
      FormsModule,
      routing
    ],
  declarations: [
    ResultComponent
  ],
  providers: [
  ]
})
export class ResultModule { }
