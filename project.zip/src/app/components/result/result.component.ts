
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ActivatedRoute } from "@angular/router";



declare var jQuery: any;


@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {

  result: number;

  constructor(private router: Router, private route: ActivatedRoute) {

  }

  ngOnInit() {
    this.result = 0;
    /*
قراءة الرقمين وجمعهما ووضعهما في النتيجة result
    */
    this.route
      .queryParams
      .subscribe(params => {
        this.result = params['num1'] + params['num2'];
      });
  }

}
