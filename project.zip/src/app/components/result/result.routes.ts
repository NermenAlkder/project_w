import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ResultComponent }   from './result.component';

const IndexRoutes: Routes = [
  {
    path: '',
    component: ResultComponent
    , pathMatch: 'full'
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(IndexRoutes);
