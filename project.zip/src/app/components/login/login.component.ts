
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

declare var jQuery: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username: string;
  password: string;
  username_err: boolean;
  password_err: boolean;

  constructor(private router: Router) {

  }

  ngOnInit() {
    //تهيئة المتحولات
    this.username = "";
    this.password = "";
    this.username_err = false;
    this.password_err = false;
  }

  login() {
    if (this.username == "") {
      this.username_err = true;
    } else {
      this.username_err = false;
    }

    if (this.password == "") {
      this.password_err = true;
    } else {
      this.password_err = false;
    }

    if (this.username != "" && this.password != "") {
      //الانتقال للواجهة الرئسية التي ندخل منها الرقمين للجمع وإرسال اسم المستخدم إليها
      this.router.navigate(['/index'], { queryParams: { 'username': this.username } });
    }


  }

}
