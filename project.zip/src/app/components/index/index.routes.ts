import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { IndexComponent }   from './index.component';

const IndexRoutes: Routes = [
  {
    path: '',
    component: IndexComponent
    , pathMatch: 'full'
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(IndexRoutes);
