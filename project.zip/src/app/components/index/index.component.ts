
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ActivatedRoute } from "@angular/router";



declare var jQuery: any;


@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {

  //اسم المستخدم
  username: string;
  //الرقم الأول
  num1: number;
  //الرقم الثاني
  num2: number;

  constructor(private router: Router, private route: ActivatedRoute) {

  }

  ngOnInit() {
    this.username = "";
    this.num1 = 0;
    this.num2 = 0;
    /*
قراءة اسم المستخدم الممرر عبر الرابط في المتصفح
    */
    this.route
      .queryParams
      .subscribe(params => {
        if (params['username'] != undefined) {
          this.username = params['username'];
        }
      });
  }

  //دالة ترسل الرقمين للواجهة result للقيام بعملية الجمع
  calc() {
    this.router.navigate(['/result'], {
      queryParams: {
        'num1': this.num1,
        'num2': this.num2
      }
    });
  }

}
